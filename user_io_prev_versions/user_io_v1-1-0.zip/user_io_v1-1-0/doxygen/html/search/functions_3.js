var searchData=
[
  ['switch_5foff_0',['switch_off',['../user__io_8h.html#a942099f6c28fb130f3da08d8d6ce32cb',1,'switch_off(enum switch_id id):&#160;user_io.c'],['../user__io_8c.html#a942099f6c28fb130f3da08d8d6ce32cb',1,'switch_off(enum switch_id id):&#160;user_io.c']]]
];
