var searchData=
[
  ['user_5fio_5fhandler_5fperiod_5fms_0',['USER_IO_HANDLER_PERIOD_MS',['../user__io__config_8h.html#a9f531730eff9baa790fdbcd7c469e59c',1,'user_io_config.h']]]
];
