var indexSectionsWithContent =
{
  0: "bilsu",
  1: "bl",
  2: "u",
  3: "bilsu",
  4: "s"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Macros"
};

