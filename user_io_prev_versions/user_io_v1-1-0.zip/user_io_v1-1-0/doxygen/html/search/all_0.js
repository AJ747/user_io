var searchData=
[
  ['btn_0',['btn',['../structbtn.html',1,'']]],
  ['btn_5fclick_1',['btn_click',['../user__io_8h.html#ad879d98a2efa7c90d3e5a8e39aaa61d8',1,'btn_click(enum btn_id id):&#160;user_io.c'],['../user__io_8c.html#ad879d98a2efa7c90d3e5a8e39aaa61d8',1,'btn_click(enum btn_id id):&#160;user_io.c']]],
  ['btn_5fdebounce_2',['btn_debounce',['../user__io_8c.html#aaf9a9565f35ae7e20ba80030e23743fb',1,'user_io.c']]],
  ['btn_5fdepressed_3',['btn_depressed',['../user__io_8h.html#ae015ca5347780f6979d385e218b3d9d1',1,'btn_depressed(enum btn_id id):&#160;user_io.c'],['../user__io_8c.html#ae015ca5347780f6979d385e218b3d9d1',1,'btn_depressed(enum btn_id id):&#160;user_io.c']]],
  ['btn_5freleased_4',['btn_released',['../user__io_8h.html#a30de6b0080f332fb749b26cacf083793',1,'btn_released(enum btn_id id):&#160;user_io.c'],['../user__io_8c.html#a30de6b0080f332fb749b26cacf083793',1,'btn_released(enum btn_id id):&#160;user_io.c']]],
  ['btns_5fhandle_5fstates_5',['btns_handle_states',['../user__io_8c.html#a24e8491ccd83d15226dd4ab4adce9da6',1,'user_io.c']]],
  ['btns_5finit_6',['btns_init',['../user__io_8c.html#ad4227c0dcceb1ee30ea7eb32648495af',1,'user_io.c']]],
  ['btns_5fno_5finput_5fms_7',['btns_no_input_ms',['../user__io_8h.html#a326b938c31c5ceac385a5e46924ded3d',1,'btns_no_input_ms(uint32_t idle_ms):&#160;user_io.c'],['../user__io_8c.html#a326b938c31c5ceac385a5e46924ded3d',1,'btns_no_input_ms(uint32_t idle_ms):&#160;user_io.c']]]
];
