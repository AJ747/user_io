var annotated_dup =
[
    [ "btn", "structbtn.html", null ],
    [ "led", "structled.html", null ]
];