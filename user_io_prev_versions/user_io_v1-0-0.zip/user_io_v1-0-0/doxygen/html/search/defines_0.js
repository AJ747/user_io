var searchData=
[
  ['btns_5fuse_0',['BTNS_USE',['../user__io__config_8h.html#aa3b0770fad714ec14f87c34e98ca2afc',1,'user_io_config.h']]]
];
